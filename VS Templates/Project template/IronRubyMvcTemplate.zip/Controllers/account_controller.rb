require 'account_membership_service'
require 'forms_authentication_service'

include System::Web::Mvc

class AccountController < Controller
  
  filter HandleErrorAttribute
  filter :change_password, AuthorizeAttribute
  
  before_action :controller do |context|
    raise System::InvalidOperationException("Windows authentication is not supported.") if context.http_context.user.identity.is_a?(System::Security::Principal)
  end
  
  accept_verbs :sign_on, :post
  
  attr_reader :forms_auth, :membership_service
  
  def initialize(forms_auth_svc=nil, membership_svc=nil)
    @forms_auth = forms_auth_svc||FormsAuthenticationService.new
    @membership_service = membership_svc||AccountMembershipService.new
  end
  
  def log_on
    view nil, 'layout'
  end
  
  def sign_on
    username = params[:username]
    return view('log_on', 'layout') unless validate_logon(username, params[:password])
    
    @forms_auth.sign_in username, params[:rememberMe]
    return redirect(params[:returnUrl]) if params.contains_key(:returnUrl)
    
    redirect_to_action 'index', 'home'
  end
  
  def log_off
    @forms_auth.sign_out
    redirect_to_action 'index', 'home'
  end
  
  def register
    @password_length = @membership_service.min_password_length
    
    if post? && validate_registration(params[:username], params[:email], params[:password], params[:confirmPassword]) 
      create_status = @membership_service.create_user(params[:username], params[:password], params[:email])
      
      if create_status == MembershipCreateStatus.success
        @forms_auth.sign_in params[:username], false
        return redirect_to_action('index', 'home')
      end
      
      model_state.add_model_error("_FORM", error_code_to_string(create_status))
    end
    
    view nil, 'layout'   
  end
  
  def change_password
    @password_length = @membership_service.min_password_length
    if post? && validate_change_password(params[:currentPassword], params[:newPassword], params[:confirmPassword])
      begin
        unless @membership_service.change_password(user.identity.name, params[:newPassword], params[:confirmPassword])
          return redirect_to_action('change_password_success') 
        end
        model_state.add_model_error "_FORM", "The current password is incorrect or the new password is invalid."
      rescue
        model_state.add_model_error "_FORM", "The current password is incorrect or the new password is invalid."
      end
    end
    view nil, 'layout'
  end
  
  private
    def validate_logon(username, password)
      model_state.add_model_error("username".to_clr_string, "You must specify a username.") if username.to_s.empty?
      model_state.add_model_error("password".to_clr_string, "You must specify a password.") if password.to_s.empty?
      model_state.add_model_error("_FORM".to_clr_string, "The username or password provided is incorrect") unless @membership_service.validate_user(username, password)
      
      return model_state.is_valid
    end
  
    def validate_registration(username, email, password, confirm_password)
      model_state.add_model_error "username".to_clr_string, "You must specify a username." if username.to_s.empty?
      model_state.add_model_error "email".to_clr_string, "You must specify an email address." if email.to_s.empty?
      if password.nil? or password.to_s.size < @membership_service.min_password_length
        model_state.add_model_error "password", "You must specify a password of #{@membership_service.min_password_length} or more characters"       
      end
      model_state.add_model_error("_FORM", "The password and confirmation password do not match") unless password == confirm_password
      
      return model_state.is_valid
    end
    
    def validate_change_password(current_password, new_password, confirm_password)
      model_state.add_model_error "currentPassword", "You must specify a current password." if current_password.to_s.empty?
      if new_password.nil? or new_password.to_s.size < @membership_service.min_password_length
        model_state.add_model_error "password", "You must specify a new password of #{@membership_service.min_password_length} or more characters"       
      end
      model_state.add_model_error("_FORM", "The new password and confirmation password do not match") unless new_password == confirm_password
      
      return model_state.is_valid
    end
    
    def error_code_to_string(create_status)
      # See http://msdn.microsoft.com/en-us/library/system.web.security.membershipcreatestatus.aspx for
      # a full list of status codes.
      case create_status
      when MembershipCreateStatus.duplicate_user_name
        return "Username already exists. Please enter a different user name."
      when MembershipCreateStatus.duplicate_email 
        return "A username for that e-mail address already exists. Please enter a different e-mail address."
      when MembershipCreateStatus.invalid_password
        return "The password provided is invalid. Please enter a valid password value."
      when MembershipCreateStatus.invalid_email
        return "The e-mail address provided is invalid. Please check the value and try again."
      when MembershipCreateStatus.invalid_answer
        return "The password retrieval answer provided is invalid. Please check the value and try again."                    
      when MembershipCreateStatus.invalid_question
        return "The password retrieval question provided is invalid. Please check the value and try again."
      when MembershipCreateStatus.invalid_user_name
        return "The user name provided is invalid. Please check the value and try again."
      when MembershipCreateStatus.provider_error
        return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator."
      when MembershipCreateStatus.user_rejected
        return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator."
      else
        return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator."
      end
    end
end