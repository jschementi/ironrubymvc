class HomeController < Controller
  
  def index
    @message = "Welcome to ASP.NET MVC!"
    view nil, 'layout'
  end
  
  def about
    view nil, 'layout'
  end
  
end