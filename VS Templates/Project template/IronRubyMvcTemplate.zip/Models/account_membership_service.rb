include System::Web::Security

class AccountMembershipService
    
  def initialize(provider=nil)
    @provider = provider||Membership.provider
  end
      
  def min_password_length
    @provider.min_required_password_length
  end

  def validate_user(user_name, password)
    @provider.validate_user user_name, password
  end
    
  def create_user(user_name, password, email)
    status = nil
    @provider.create_user user_name, password, email, nil, nil, true, nil, status
    status
  end

  def change_password(user_name, old_password, new_password) 
    current_user = @provider.get_user user_name, true 
    current_user.change_password old_password, new_password
  end
end