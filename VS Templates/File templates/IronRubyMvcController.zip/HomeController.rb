class HomeController < Controller
  
  def index
    # the index action
  end
  
end