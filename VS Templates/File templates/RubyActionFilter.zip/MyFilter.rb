class RubyActionFilter < ActionFilter
  
  def on_action_executing(context)
    # put before action execution filter logic here
  end
  
  def on_action_executed(context)
    # put after action execution filter logic here
  end
  
end