class RubyAuthorizationFilter < AuthorizationFilter      
  
  def on_authorization(context)
    # put authorization logic here
  end
  
end