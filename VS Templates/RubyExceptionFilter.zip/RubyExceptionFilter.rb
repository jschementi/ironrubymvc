class RubyExceptionFilter < ExceptionFilter      
  
  def on_exception(context)
    # put exception handling here
  end
  
end